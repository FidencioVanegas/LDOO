function aceptar()
{
	alert("Enviando...");
}

function cancelar()
{
   alert("Usted cancelo");
}