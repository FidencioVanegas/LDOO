function aceptar()
{
      confirm("mensaje");
}

function cancelar()
{
   alert("Usted cancelo");
}